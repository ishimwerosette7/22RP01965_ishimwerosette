<?php
session_start();
if(isset($_SESSION['username']))
{
header("localhost:homepage.php");
}
?>
<html>
<body>
	
<fieldset style="width: 300px;background-color: green">
<h2>LOGIN FORM</h2>
	<form action="" method="POST">
		username:<input type="text" name="username"><br>
		password:<input type="password" name="password"><br>
        <input type="submit" name="login" value="login">
        </fieldset>
    </form>
    <?php
if(isset($_POST['login']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$a=mysqli_connect("localhost","root","","student_management");
	if(empty($username) && empty($password))
	{
		echo"All fields are required";
	}
	else
	{
	$query=mysqli_query($a,"SELECT * FROM users where username='$username' AND password='$password'");
	if(mysqli_num_rows($query)>0)
	{
		$_SESSION['username']=$username;
			header("location:homepage.php");
		}
		else{
			echo "invalid password";
		}
	}
}
echo "<a href='homepage.php'>homepage</a>";
?>
</body>
</html>