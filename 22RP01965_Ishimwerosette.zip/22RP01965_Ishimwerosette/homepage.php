<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #4CAF50;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .header p {
            margin: 0;
            font-size: 1.2em;
        }
        .nav {
            background-color: #e0e0e0;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
             align-items: center;
        }
        .nav a {
            float: left;
            display: block;
            color: #333;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
            font-size: 1em;

        }
        .nav a:hover {
            background-color: #f0f0f0;
            color: black;
        }
        .content {
            padding: 20px;
            text-align: center;
        }
        iframe {
            border: none;
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <div class="header">

        <p>Welcome to the homepage
        <?php
        session_start();
        echo isset($_SESSION['users']) ? htmlspecialchars($_SESSION['users']) : 'Rosette';
        ?>
        </p>
    </div>
    <div class="nav">
    	
    	  <h2><center>Menu</center></h2>
        <a href="form.php" target="x">form</a>
        <a href="login.php">Login</a>
        <a href="logout.php">Logout</a>
    
    </div>
    <div>
    	<p>Welcome to my website<br>
    </div>
    <div class="content">
      
        <iframe name="x" width="100%" height="600px">
        	  <div>
        	  	
        	  </div>
        </iframe>
    </div>
</body>
</html>
