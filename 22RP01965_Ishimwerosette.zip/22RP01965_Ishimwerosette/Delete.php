<?php
$a =mysqli_connect("localhost", "root", "", "student_management");
if(isset($_GET['id'])){
    $id=$_GET['id'];
$del=mysqli_query($a,"DELETE FROM student WHERE id='$id'");
if($del)
{
    echo"<script>alert('data is Removed');window.location='select.php';</script>";
    
}
else{
    echo"<script>alert('Not Removed ');window.location='select.php';</script>";
}
}
?>