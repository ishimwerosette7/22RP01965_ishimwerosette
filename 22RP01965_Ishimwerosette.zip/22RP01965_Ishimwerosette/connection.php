<?php
$a=mysqli_connect("localhost","root","","student_management");
?>