<html>
<body>
<head>
	<style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .header p {
            margin: 0;
            font-size: 1.2em;
        }
        .nav {
            background-color: gray;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .nav a {
            float: left;
            display: block;
            color: #333;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
            font-size: 1em;
        }
        .nav a:hover {
            background-color: #ddd;
            color: black;
        }
        .content {
            padding: 20px;
            text-align: center;
        }
        iframe {
            border: none;
            margin-top: 20px;
        }
    </style>
<link rel="stylesheet" type="text/css" href="css.php">
</head>
<?php 
session_start();
 ?>
 <p>
 	welcome here!!
 </p>
 <div>
<center>
 <a href="login.php" target="x">login</a>
 <a href="logout.php" target="x">logout</a>
</center>
</div>
<iframe name="x" height="11099" width="100%" ></iframe>
</body>
</html>